function showAlert() {
    alert("hey!");
}
